import gymnasium as gym
env = gym.make('Blackjack-v1', natural=False, sab=False, render_mode= None) 
###YOUR Q-LEARNING CODE BEGINS
import random
import numpy as np
#setting hyperparameters:
alpha=0.3            #learning rate
gamma=0.9              #discount
epsilon=1.0             #exploration rate
epsilon_decay=0.999   
epsilon_min=0.05
episodes=50000        #number of episodes for training
#initializing Q-table
Q={}
for sum_player in range(4,32):
    for dealer_card in range (1, 11):
        for usable_ace in [True, False]:
            state=(sum_player, dealer_card, usable_ace)
            Q[state]=[0.0, 0.0]
#implementing Q-Learning
def train_agent():
    global epsilon
    episode_rewards=[]
    wins=0
    losses=0
    draws=0
    for ep in range(episodes):
        state,_= env.reset()
        done=False
        total_reward = 0
        while not done:
            if random.uniform(0,1) < epsilon:
                action=env.action_space.sample() #exploration
            else:
                action=np.argmax(Q[state]) #exploitation
            next_state, reward,terminated, truncated, _=env.step(action)
            done=terminated or truncated
            total_reward+=reward
            if next_state in Q:
                next_best_action = np.argmax(Q[next_state])
                Q[state][action] = Q[state][action] + alpha * (
                    reward + gamma * Q[next_state][next_best_action] - Q[state][action]
                )
            state = next_state
        episode_rewards.append(total_reward)
        if total_reward==1:
            wins+=1
            print(f"Episode {ep + 1}: Win")
        elif total_reward == -1:
            losses += 1
            print(f"Episode {ep + 1}: Loss")
        else:
            draws += 1
            print(f"Episode {ep + 1}: Draw")
        if epsilon > epsilon_min:
            epsilon *= epsilon_decay
    win_rate = (wins / episodes) * 100
    print(f"Total Win Rate: {win_rate:.2f}%")

    print("training done")
train_agent()
env.close()
###YOUR Q-LEARNING CODE ENDS