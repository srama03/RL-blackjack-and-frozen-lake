import gymnasium as gym
env = gym.make('FrozenLake-v1', desc=None, map_name="4x4", is_slippery=True, render_mode=None)
# Your code for Q2.2 which Executes Random Policy until 1000 episodes
import numpy as np
from collections import defaultdict
episodes=1000
transitions = defaultdict(lambda: defaultdict(lambda: defaultdict(int)))
rewards = defaultdict(lambda: defaultdict(lambda: defaultdict(float)))
for ep in range(episodes):
    state, _ = env.reset()
    done = False
    while not done:
        action = env.action_space.sample() 
        next_state, reward, terminated, truncated, _ = env.step(action)
        done = terminated or truncated

        transitions[state][action][next_state] += 1
        rewards[state][action][next_state] += reward

        state = next_state
T = defaultdict(lambda: defaultdict(lambda: defaultdict(float)))
R = defaultdict(lambda: defaultdict(lambda: defaultdict(float)))
for s in transitions:
    for a in transitions[s]:
        total=sum(transitions[s][a].values())
        for s_prime in transitions[s][a]:
            T[s][a][s_prime]=transitions[s][a][s_prime]/total
            R[s][a][s_prime]= rewards[s][a][s_prime]/total

# Your code for Q2.3 which implements Value Iteration
V = np.full(env.observation_space.n, 0.1)
gamma=0.6
threshold=1e-7
while True:
    delta=0
    for s in range(env.observation_space.n):
        v=V[s]
        new= -float("inf")
        for a in range(env.observation_space.n):
            action_val=0
            for s_prime in T[s][a]:
                action_val+=T[s][a][s_prime]*(R[s][a][s_prime] + gamma * V[s_prime])
            new=max(action_val, new)
        V[s]=new 
        delta = max(delta, abs(v - V[s]))  
    if delta<threshold:
        break
#Your code for Q2.4 which implements Policy Extraction
policy=np.zeros(env.observation_space.n, dtype=int)
for s in range(env.observation_space.n):
    action_values=[]
    for a in range(env.observation_space.n):
        action_val=0
        for s_prime in T[s][a]:
            action_val+=T[s][a][s_prime]*(R[s][a][s_prime] + gamma * V[s_prime])
        action_values.append(action_val)
    policy[s]=np.argmax(action_values)
env.close()
# Your code for Q2.5 which executes the optimal policy
env = gym.make('FrozenLake-v1', desc=None, map_name="4x4", is_slippery=True, render_mode="human")
episodes=10
for ep in range(episodes):
    state, _=env.reset()
    done=False
    while not done:
        action=policy[state]
        next_state, reward, terminated, truncated, _=env.step(action)
        done=terminated or truncated
        state=next_state
env.close()
